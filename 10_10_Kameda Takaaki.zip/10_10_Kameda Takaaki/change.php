<?php
require "funcs.php";

//メールアドレス取得
$email = $_POST["mail"];

//DB接続
$pdo = db_connect();

//２．データ取得SQL作成
$stmt = $pdo->prepare("SELECT * FROM gs_kadai_table WHERE email='$email'");
$stmt ->bindvalue(":email",$email,PDO::PARAM_INT);//PDO::PARAM_STR
$status = $stmt->execute();

//結果をfetch()
if ($status == false) { 
//SQLエラー関数
sql_error($stmt);
}else{
$row = $stmt->fetch();
}

?>


<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登録情報編集</title>
</head>
<body>

<form method="POST" action="update.php">
    <div>
        <p>登録情報編集</p>
        <p>企業名：<input type="text" name="name" value="<?=$row['name']?>"></p>
        <p>メールアドレス：<input type="text" name="email" value="<?=$row['email']?>"></p>
        <p>パスワード：<input type="password" name="pw" value="<?=$row['pw']?>"></p>
        <p>関連SDGs：<input type="text" name="sdgs" value="<?=$row['sdgs']?>"></p>
        <p>企業紹介：<textArea name="naiyou" rows="4" cols="40"><?=$row['introduce']?></textArea></p>
        <input type="hidden" name="id" value="<?=$row['id']?>">
        <input type="submit" value="更新">
    </div>
</form>

<br>

<div>
  <a href="logout.php">ログアウト</a>
</div>

<br>

</body>
</html>