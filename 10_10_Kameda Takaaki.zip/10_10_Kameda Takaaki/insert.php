<?php
require "funcs.php";

//DB接続
$pdo = db_connect();

$name = $_POST["name"];
$email = $_POST["mail"];
$pw = $_POST["pw"];
$naiyou = $_POST["naiyou"];
$sdgs = $_POST["sdgs"];

//データ登録SQL作成
$stmt = $pdo->prepare("INSERT INTO gs_kadai_table(id,name,email,pw,sdgs,introduce,indate)VALUES(null,:a1,:a2,:a3,:a4,:a5,sysdate())");
$stmt->bindValue(':a1', $name, PDO::PARAM_STR); 
$stmt->bindValue(':a2', $email, PDO::PARAM_STR);
$stmt->bindValue(':a3', $pw, PDO::PARAM_STR);
$stmt->bindValue(':a4', $sdgs, PDO::PARAM_STR); 
$stmt->bindValue(':a5', $naiyou, PDO::PARAM_STR); 
$status = $stmt->execute();

//データ登録処理後
if($status==false){
  $error = $stmt->errorInfo();
  exit("ErrorMassage:".$error[2]);
}else{
  header('Location: index.php');
}
?>