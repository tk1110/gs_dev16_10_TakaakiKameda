<?php
require "funcs.php";

//DB接続
$pdo = db_connect();

// try {
//   $pdo = new PDO('mysql:dbname=gs_db_07_kadai;charset=utf8;host=localhost','root','root');
// } catch (PDOException $e) {
//   exit('DBConnectError:'.$e->getMessage());
// }  


//データ取得SQL作成
$kensaku = $_POST["kensaku"];
$image = $_POST["icon"];

// echo $image;

// echo "SELECT * FROM gs_bm_table WHERE introduce LIKE '$kensaku'";

// echo "SELECT * FROM gs_bm_table WHERE introduce LIKE '$image'";


if ( isset($kensaku) ) {
  $stmt = $pdo->prepare("SELECT * FROM gs_kadai_table WHERE introduce LIKE '%".$_POST["kensaku"]."%'");
  $status = $stmt->execute();
} else {
  $stmt = $pdo->prepare("SELECT * FROM gs_kadai_table WHERE sdgs LIKE '$image'");
  $status = $stmt->execute();  
};

// $stmt = $pdo->prepare("SELECT * FROM gs_bm_table WHERE introduce LIKE '%".$_POST["kensaku"]."%'");
// $status = $stmt->execute();

// $stmt = $pdo->prepare("SELECT * FROM gs_bm_table WHERE sdgs LIKE '$image'");
// $status = $stmt->execute();  

//データ表示
$view="";
if($status==false) {
  $error = $stmt->errorInfo();
  exit("ErrorQuery:".$error[2]);

}else{
  while( $result = $stmt->fetch(PDO::FETCH_ASSOC)){ 
    $view .= "<div style='
    width: 600px;
    height: 200px;
    border: solid #005f96 0.3px;
    margin: 10px auto;
    padding: 10px 20px;
    '>";
    $view .= "<p>【会社名】</br>";
    $view .= $result['name'];
    $view .= "</p>";
    $view .= "</br>";
    $view .= "<p>【メールアドレス】</br>";
    $view .= $result['email'];
    $view .= "</p>";
    $view .= "</br>";
    $view .= "<p>【関連SDGs】</br>";
    $view .= $result['sdgs'];
    $view .= "</p>";
    $view .= "</br>";
    $view .= "<p>【企業詳細】</br>";
    $view .= $result['introduce'];
    $view .= "</p>";
    $view .= "</br>";
    $view .= "</div>";
  }
}
?>

<style>
.title {
  width: 600px;
  height: 20px;
  font-size: 20px;
  text-align: center;
  margin: 30px auto;
}

.box {
  width: 600px;
  height: 300px;
  border: solid #005f96 0.3px;
  margin: 10px auto;
  padding: 10px 20px;
}

.index_guide{
  width: 600px;
  height: 20px;
  margin: 30px auto 30px auto;
  text-align: right;

}

</style>

<!DOCTYPE html>
<html lang="ja">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="css/reset.css">
      <link rel="stylesheet" href="css/result_stylesheet.css">
      <title>検索結果</title>
  </head>

  <body>
      <div class="index_guide">
                <p><a href="index.php" class="back">戻る</a></p>
      </div>

      <div class="title">
            <p>検索結果</p>
      </div>

      <?=$view?>
  </body>
</html>