<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/index_stylesheet.css">
    <title>Will</title>
</head>
<body>

    <!-- 企業登録画面への案内 -->
    <div class="register_guide">
        <p>企業担当者の方は<a href="register.php" class="action">こちら</a></p>
    </div>

    <!-- サービスタイトル -->
    <div class="title">
        <h1><span class="color">I</span>&nbsp;n&nbsp;t&nbsp;e&nbsp;r&nbsp;e&nbsp;s&nbsp;t</h1>
        <p class="sub_title">Find Interesting Company & Job.</p>
    </div>

    <!-- 検索バー -->
    <form class="serch_box" method="post" action="result.php">
        <input name="kensaku" type="text"  style="width:400px;" id="input" value="">
        <input type="submit" value="検索">
    </form>

    <!-- SDGsアイコン -->
    <div class="icon_box">

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_01_ja_2.png" name="icon" alt="送信する" value="sdgs01">
                <!-- <input type="submit" name="icon01" alt="送信する" value="sdgs01">
                <img src="img/icon/sdg_icon_01_ja_2.png" alt=""> -->
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_02_ja_2.png" name="icon" alt="送信する" value="sdgs02">
                <!-- <input type="submit" name="icon01" alt="送信する" value="sdgs01">
                <img src="img/icon/sdg_icon_01_ja_2.png" alt=""> -->
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_03_ja_2.png" name="icon" alt="送信する" value="sdgs03">
                <!-- <input type="submit" name="icon01" alt="送信する" value="sdgs01">
                <img src="img/icon/sdg_icon_01_ja_2.png" alt=""> -->
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_04_ja_2.png" name="icon" alt="送信する" value="sdgs04">
                <!-- <input type="submit" name="icon01" alt="送信する" value="sdgs01">
                <img src="img/icon/sdg_icon_01_ja_2.png" alt=""> -->
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_05_ja_2.png" name="icon" alt="送信する" value="sdgs05">
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_06_ja_2.png" name="icon" alt="送信する" value="sdgs06">
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_07_ja_2.png" name="icon" alt="送信する" value="sdgs07">
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_08_ja_2.png" name="icon" alt="送信する" value="sdgs08">
            </form>
        </div>


        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_09_ja_2.png" name="icon" alt="送信する" value="sdgs09">
            </form>
        </div>


        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_10_ja_3.png" name="icon" alt="送信する" value="sdgs10">
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_11_ja_2.png" name="icon" alt="送信する" value="sdgs11">
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_12_ja_2.png" name="icon" alt="送信する" value="sdgs12">
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_13_ja_2.png" name="icon" alt="送信する" value="sdgs13">
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_14_ja_2.png" name="icon" alt="送信する" value="sdgs14">
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_15_ja_2.png" name="icon" alt="送信する" value="sdgs15">
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_16_ja_2.png" name="icon" alt="送信する" value="sdgs16">
            </form>
        </div>

        <div class="icon_item">
            <form method="post" action="result.php">
                <input class="icon" type="image" src="img/icon/sdg_icon_17_ja_2.png" name="icon" alt="送信する" value="sdgs17">
            </form>
        </div>

    </div>

    <!-- <div class="serch_box">
        <div class="search_bar"></div>
        <div class="send_box">検索</div>
    </div> -->

    <!-- 検索バーの下の説明部分
    <div class="explanation_box">
        <p>
            あなたの"<span class="color bold">興味</span>"を</br>
            #ハッシュタグ で検索しよう。
        </p>
    </div> -->
        
</body>
</html>