<?php

//DB接続
try {
  $pdo = new PDO('mysql:dbname=gs_db_07_kadai;charset=utf8;host=localhost','root','root');
} catch (PDOException $e) {
  exit('DBConnectError:'.$e->getMessage());
}

$name = $_POST["name"];
// $image = $_POST["image"];
$sdgs = $_POST["sdgs"];
$naiyou = $_POST["naiyou"];

//データ登録SQL作成
$stmt = $pdo->prepare("INSERT INTO gs_bm_table(id,name,sdgs,introduce,indate)VALUES(null,:a1,:a2,:a3,sysdate())");
$stmt->bindValue(':a1', $name, PDO::PARAM_STR); 
// $stmt->bindValue(':a2', $image);
$stmt->bindValue(':a2', $sdgs, PDO::PARAM_STR); 
$stmt->bindValue(':a3', $naiyou, PDO::PARAM_STR); 
$status = $stmt->execute();

//データ登録処理後
if($status==false){
  $error = $stmt->errorInfo();
  exit("ErrorMassage:".$error[2]);
}else{
  header('Location: index.php');
}
?>