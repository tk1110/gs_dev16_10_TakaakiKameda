<?php
//DB接続
try {
    $pdo = new PDO('mysql:dbname=gs_db_07_kadai;charset=utf8;host=localhost','root','root');
  } catch (PDOException $e) {
    exit('DBConnectError:'.$e->getMessage());
  }  

//データ取得SQL作成
$kensaku = $_POST["kensaku"];
$image = $_POST["image"];

$stmt = $pdo->prepare("SELECT * FROM gs_bm_table WHERE introduce LIKE '%".$_POST["kensaku"]."%'");
$status = $stmt->execute();

// $stmt = $pdo->prepare("SELECT * FROM gs_bm_table WHERE introduce LIKE '%$image%'");
// $status = $stmt->execute();

//データ表示
$view="";
if($status==false) {
  $error = $stmt->errorInfo();
  exit("ErrorQuery:".$error[2]);

}else{
  while( $result = $stmt->fetch(PDO::FETCH_ASSOC)){ 
    $view .= "<p>";
    $view .= $result['name'];
    $view .= "</p>";
    $view .= "<p>";
    $view .= $result['sdgs'];
    $view .= "</p>";
    $view .= "<p>";
    $view .= $result['introduce'];
    $view .= "</p><br>";
  }

}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/reset.css">
    <title>検索結果</title>
</head>
<body>
    <div>
        <div><?=$view?></div>
    </div>
</body>
</html>