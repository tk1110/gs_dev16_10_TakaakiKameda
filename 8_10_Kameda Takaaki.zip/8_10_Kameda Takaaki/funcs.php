<?php
//XSS対応
function h($str)
{
    return htmlspecialchars($str, ENT_QUOTES);
}

//DB接続
function db_connect() {
  try {
    //Password:MAMP='root',XAMPP=''
    return new PDO('mysql:dbname=gs_db_10_kameda;charset=utf8;host=localhost','root','root');
  } catch (PDOException $e) {
    exit('DBConnectError:'.$e->getMessage());
  }  
}

//SQLエラー
function sql_error($stmt){
  //execute（SQL実行時にエラーがある場合）
  $error = $stmt->errorInfo();
  exit("SQLError:".$error[2]);
}

//リダイレクト
function redirect($file_name){
  header("Location: ".$file_name);
  exit();
}

?>