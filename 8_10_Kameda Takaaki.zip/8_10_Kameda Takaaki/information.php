<?php
require "funcs.php";

//メールアドレス取得
$email = $_POST["mail"];

//DB接続
$pdo = db_connect();

//２．データ取得SQL作成
$stmt = $pdo->prepare("SELECT * FROM gs_kadai_table WHERE email='$email'");
$stmt ->bindvalue(":email",$email,PDO::PARAM_INT);//PDO::PARAM_STR
$status = $stmt->execute();

//結果をfetch()
if ($status == false) { 
//SQLエラー関数
sql_error($stmt);
}else{
$row = $stmt->fetch();
}

?>


<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登録情報</title>
</head>
<body>

<form method="POST" action="change.php">
    <div>
        <br><br>
        <p>登録情報</p>
        <p>企業名：<?=$row['name']?></p>
        <p>メールアドレス：<?=$row['email']?></p>
        <p>関連SDGs：<?=$row['sdgs']?></p>
        <p>企業紹介：<?=$row['introduce']?></p>
        <input type="hidden" name="mail" value="<?=$row['email']?>">
        <input type="submit" value="情報編集">&nbsp;&nbsp;
    </div>
</form>

<form method="GET" action="delete.php">
    <div>
        <br>
        <input type="hidden" name="id" value="<?=$row['id']?>">
        <input type="submit" value="情報削除">&nbsp;&nbsp;
    </div>
</form>

<br>

<p><a href="index.php">戻る</a></p>
    
</body>
</html>