<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/register_stylesheet.css">
    <title>新規登録</title>
</head>
<body>

<form method="post" action="insert.php" enctype="multipart/form-data">
  <div>
       <fieldset>
            <div class="index_guide">
                <p><a href="index.php" class="back">戻る</a></p>
            </div>

            <div class="register_box">

                <div class="register_title">
                    <legend>企業登録フォーム</legend>
                </div>

                <div class="r_box">
                    <label>企業名<br>
                        <input type="text" name="name" style="width:400px;">
                    </label><br><br>

                    <!-- <label>企業ロゴ<br>
                        <input type="file" name="image">
                    </label><br><br> -->

                    <label>メールアドレス<br>
                        <input type="text" name="mail" style="width:400px;">
                    </label><br><br>

                    <label>関連SDGs<br>
                        <select name="sdgs" style="width:200px;">
                            <option value="">選択してください</option>
                            <option value="sdgs01">01：貧困をなくそう</option>
                            <option value="sdgs02">02：飢餓をゼロに</option>
                            <option value="sdgs03">03：すべての人に健康と福祉を</option>
                            <option value="sdgs04">04：質の高い教育をみんなに</option>
                            <option value="sdgs05">05：ジェンダー平等を実現しよう</option>
                            <option value="sdgs06">06：安全なトイレを世界中に</option>
                            <option value="sdgs07">07：エネルギーをみんなに、そしてクリーンに</option>
                            <option value="sdgs08">08：働きがいも経済成長も</option>
                            <option value="sdgs09">09：産業と技術革新の基盤をつくろう</option>
                            <option value="sdgs10">10：人や国の不平等をなくそう</option>
                            <option value="sdgs11">11：住み続けられるまちづくりを</option>
                            <option value="sdgs12">12：つくる責任、つかう責任</option>
                            <option value="sdgs13">13：気候変動に具体的な対策を</option>
                            <option value="sdgs14">14：海の豊かさを守ろう</option>
                            <option value="sdgs15">15：陸の豊かさも守ろう</option>
                            <option value="sdgs16">16：平和と公正をすべての人に</option>
                            <option value="sdgs17">17：パートナーシップで目標を達成しよう</option>
                        </select>
                    </label><br><br>

                    <label>企業紹介<br> 
                        <textArea name="naiyou" rows="10" cols="60"></textArea>
                    </label><br><br>

                    <input type="submit" value="登録">

                </div>

            </div>

        </fieldset>
  </div>
</form>

    
</body>
</html>