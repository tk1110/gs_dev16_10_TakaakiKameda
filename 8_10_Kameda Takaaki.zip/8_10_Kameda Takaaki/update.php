<?php
//データ取得
$id = $_POST["id"];
$name = $_POST["name"];
$email = $_POST["email"];
$sdgs = $_POST["sdgs"];
$naiyou = $_POST["naiyou"];

// echo $id;
// echo $name;
// echo $email;
// echo $sdgs;
// echo $naiyou;


//2.DB接続
require "funcs.php";
$pdo = db_connect();

//データ更新処理
$stmt = $pdo->prepare("UPDATE gs_kadai_table SET name=:a1, email=:a2, sdgs=:a3, introduce=:a4 WHERE id=:id");
$stmt->bindValue(':a1', $name, PDO::PARAM_STR); 
$stmt->bindValue(':a2', $email, PDO::PARAM_STR);
$stmt->bindValue(':a3', $sdgs, PDO::PARAM_STR); 
$stmt->bindValue(':a4', $naiyou, PDO::PARAM_STR); 
$stmt->bindValue(':id', $id, PDO::PARAM_STR);  
$status = $stmt->execute();

$stmt = $pdo->prepare("INSERT INTO gs_kadai_table(id,name,email,sdgs,introduce,indate)VALUES(null,:a1,:a2,:a3,:a4,sysdate())");

if($status==false) {
    //SQLエラー関数
    sql_error($stmt);
  }else{

   //トップページへ戻る
   redirect('index.php');
  }
?>