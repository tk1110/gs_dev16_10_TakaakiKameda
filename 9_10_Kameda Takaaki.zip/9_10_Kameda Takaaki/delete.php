<?php
//ID取得
$id = $_GET["id"];

// DB接続
require "funcs.php";

$pdo = db_connect();

//SQL作成
$delete = $pdo->prepare("DELETE FROM gs_kadai_table WHERE id=:id");
$delete->bindvalue(":id",$id,PDO::PARAM_INT);

//SQL実行
$status = $delete->execute();

//トップページへ戻る
if ($status == false) { 
    //SQLエラー関数
    sql_error($delete);
  }else{
    redirect('index.php');
  }

?>