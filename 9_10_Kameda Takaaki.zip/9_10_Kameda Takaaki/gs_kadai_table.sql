-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 
-- サーバのバージョン： 5.6.34-log
-- PHP Version: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gs_db_10_kameda`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `gs_kadai_table`
--

CREATE TABLE `gs_kadai_table` (
  `id` int(12) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `pw` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sdgs` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `introduce` text COLLATE utf8_unicode_ci NOT NULL,
  `indate` datetime NOT NULL,
  `kanri_flg` int(1) NOT NULL,
  `life_flg` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `gs_kadai_table`
--

INSERT INTO `gs_kadai_table` (`id`, `name`, `email`, `pw`, `sdgs`, `introduce`, `indate`, `kanri_flg`, `life_flg`) VALUES
(1, '株式会社SDGs01', 'sdgs01@test.com', 'sdgs01', 'sdgs01', 'SDGs01 テストです。３', '2020-06-20 00:30:44', 0, 0),
(4, '株式会社SDGs04', 'sdgs04@test.com', 'sdgs04', 'sdgs04', 'SDGs04 テストです。\r\n修正', '2020-06-20 00:48:38', 0, 0),
(5, '株式会社SDGs01_2', 'sdgs01_2@test.com', 'sdgs01_2', 'sdgs01', '貧困をなくそう', '2020-06-20 00:52:09', 0, 0),
(8, '株式会社テストカンパニー', 'test@test.com', 'test@test.com', 'sdgs17', 'tesu', '2020-06-20 15:08:25', 0, 0),
(10, '管理者ユーザー', 'kanri@test.jp', '$2y$10$4emZQF0EBVn33mVW6RU./ecRcLFnc3zSGYamh7J2xvcy8Xbk5bYOW', '', '管理用ユーザー', '2020-07-02 22:36:24', 1, 0),
(11, '株式会社SDGs02', 'sdgs02@test.com', 'sdgs02', 'sdgs02', 'sdgs02　飢餓をゼロに', '2020-07-04 00:53:59', 0, 0),
(12, '株式会社SDGs03', 'sdgs03@test.com', 'sdgs03', 'sdgs03', 'sdgs03 すべての人に健康と福祉を', '2020-07-04 00:54:45', 0, 0),
(13, '株式会社SDGs05', 'sdgs05@test.com', 'sdgs05', 'sdgs05', 'sdgs05　ジェンダー平等を実現しよう', '2020-07-04 00:56:01', 0, 0),
(14, '株式会社SDGs06', 'sdgs06@test.com', 'sdgs06', 'sdgs06', 'sdgs06 安全なトイレを世界中に', '2020-07-04 00:58:15', 0, 0),
(15, '株式会社SDGs07', 'sdgs07@test.com', 'sdgs07', 'sdgs07', 'sdgs07　エネルギーをみんなに、そしてクリーンに', '2020-07-04 00:59:03', 0, 0),
(16, '株式会社SDGs08', 'sdgs08@test.com', 'sdgs08', 'sdgs08', 'sdgs08 働きがいも経済成長も', '2020-07-04 00:59:56', 0, 0),
(17, '株式会社SDGs09', 'sdgs09@test.com', 'sdgs09', 'sdgs09', 'sdgs09 産業と技術革新の基盤をつくろ', '2020-07-04 01:00:29', 0, 0),
(18, '株式会社SDGs10', 'sdgs10@test.com', 'sdgs10', 'sdgs10', 'sdgs10 人や国の不平等をなくそう', '2020-07-04 01:01:00', 0, 0),
(19, '株式会社SDGs11', 'sdgs11@test.com', 'sdgs11', 'sdgs11', 'sdgs11　住み続けられるまちづくりを', '2020-07-04 01:02:13', 0, 0),
(20, '株式会社SDGs12', 'sdgs12@test.com', 'sdgs12', 'sdgs12', 'sdgs12 つくる責任、つかう責任', '2020-07-04 01:03:23', 0, 0),
(21, '株式会社SDGs13', 'sdgs13@test.com', 'sdgs13', 'sdgs13', 'sdgs13 気候変動に具合的な対策を', '2020-07-04 01:03:56', 0, 0),
(22, '株式会社SDGs14', 'sdgs14@test.com', 'sdgs14', 'sdgs14', 'sdgs14 海の豊かさを守ろう', '2020-07-04 01:04:33', 0, 0),
(23, '株式会社SDGs15', 'sdgs15@test.com', 'sdgs15', 'sdgs15', 'sdgs15 陸の豊かさも守ろう', '2020-07-04 01:05:03', 0, 0),
(24, '株式会社SDGs16', 'sdgs16@test.com', 'sdgs16', 'sdgs16', 'sdgs16 平和と公正をすべての人に', '2020-07-04 01:05:45', 0, 0),
(25, '株式会社SDGs17', 'sdgs17@test.com', 'sdgs17', 'sdgs17', 'sdgs17 パートナーシップで目標を達成しよう', '2020-07-04 01:06:18', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gs_kadai_table`
--
ALTER TABLE `gs_kadai_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gs_kadai_table`
--
ALTER TABLE `gs_kadai_table`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
