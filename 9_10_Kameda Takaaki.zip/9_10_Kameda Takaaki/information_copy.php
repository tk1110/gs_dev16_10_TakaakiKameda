<?php
// セッションスタート
session_start();

require "funcs.php";

// SQL用に変数として保持しておく
$name = $_SESSION["name"];

// ログインチェック処理
loginCheck();

//DB接続
$pdo = db_connect();

//データ取得SQL作成
$stmt = $pdo->prepare("SELECT * FROM gs_kadai_table WHERE name=:name");
$stmt->bindValue(':name', $name, PDO::PARAM_STR);
$status = $stmt->execute();

//データ表示
$view="";
if($status==false) {
  sql_error($stmt);
}else{
    $r = $stmt->fetch(PDO::FETCH_ASSOC);
    $e = $r["email"];

    $view .= '<form method="POST" action="change.php">';
    $view .= '<div>';
    $view .= '<br><br>';
    $view .= '<p style=" font-size: 18px; font-weight: bold;">登録情報</p>';
    $view .= '<p>企業名：';
    $view .=  $r["name"];
    $view .= '</p>';
    $view .= '<p>メールアドレス：';
    $view .=  $r["email"];
    $view .= '</p>';
    $view .= '<p>パスワード：';
    $view .=  $r["pw"];
    $view .= '</p>';
    $view .= '<p>関連SDGs：';
    $view .=  $r["sdgs"];
    $view .= '</p>';
    $view .= '<p>企業紹介：';
    $view .=  $r["introduce"];
    $view .= '</p>';
    $view .= '<input type="hidden" name="mail" value="';
    $view .=  $e;
    $view .= '"</p>';

    $view .= '<input type="submit" value="情報編集">&nbsp;&nbsp;';
    $view .= '</div>';
    $view .= '</form>';
}

?>


<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登録情報</title>
</head>
<body>

<div>
    <?=$view?>
</div>


<form method="GET" action="delete.php">
    <div>
        <br>
        <input type="hidden" name="id" value="<?=$r['id']?>">
        <input type="submit" value="情報削除">
    </div>
</form>

<br>

<div>
  <a href="logout.php">ログアウト</a>
</div>

<br>

<p><a href="index.php">戻る</a></p>
    
</body>
</html>