<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ログイン</title>
</head>
<body>
    <h1>ログイン画面</h1>

    <!-- <form method="post" action="information.php" enctype="multipart/form-data">

        <div>
            <p>メールアドレスを入力してください</p>
            <input type="text" name="mail" style="width:400px;">
        </div>

        <input type="submit" value="ログイン"> -->

        <form name="form1" action="login_act.php" method="post">
        メールアドレス:<input type="text" name="email" /><br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;パスワード:<input type="password" name="pw" /><br><br>
        <input type="submit" value="LOGIN" />
        </form>

        <br>
        <br>

        <div class="navbar-header"><a href="index.php">トップページへ戻る</a></div>


    <!-- </form> -->
</body>
</html>