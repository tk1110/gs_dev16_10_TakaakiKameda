<?php

ini_set( 'display_errors', 1 );

//セッションスタート
session_start();

//POSTの値を取得
$email = $_POST["email"];
$pw = $_POST["pw"];

//DB接続
include("funcs.php");
$pdo = db_connect();

//データ取得SQL作成
$stmt = $pdo->prepare("SELECT * FROM gs_kadai_table WHERE email=:email AND pw=:pw");
$stmt->bindValue(':email', $email, PDO::PARAM_STR);
$stmt->bindValue(':pw', $pw, PDO::PARAM_STR); 
$status = $stmt->execute();

//エラー時のストップ処理
if($status==false){
    sql_error($stmt);
}

//抽出データ数を取得
$val = $stmt->fetch(); 

//該当レコードがあればSESSIONに値を代入
// if(password_verify($pw, $val["pw"])){
if( $val["email"] != "" ){
  //Login成功時
  $_SESSION["chk_ssid"]  = session_id();
  $_SESSION["kanri_flg"] = $val['kanri_flg'];
  $_SESSION["name"]      = $val['name'];
  header("Location: information_copy.php");
}else{
  //Login失敗時はindexに戻る
  header("Location: index.php");

}

exit();


