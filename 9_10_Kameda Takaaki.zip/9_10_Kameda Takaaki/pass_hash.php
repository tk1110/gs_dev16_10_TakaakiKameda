<?php

$hashpass = password_hash("kanri",PASSWORD_DEFAULT);

echo $hashpass;

?>