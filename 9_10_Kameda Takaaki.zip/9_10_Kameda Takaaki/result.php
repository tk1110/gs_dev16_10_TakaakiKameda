<?php
require "funcs.php";

//DB接続
$pdo = db_connect();

// try {
//   $pdo = new PDO('mysql:dbname=gs_db_07_kadai;charset=utf8;host=localhost','root','root');
// } catch (PDOException $e) {
//   exit('DBConnectError:'.$e->getMessage());
// }  


//データ取得SQL作成
$kensaku = $_POST["kensaku"];
$image = $_POST["icon"];

// echo $image;

// echo "SELECT * FROM gs_bm_table WHERE introduce LIKE '$kensaku'";

// echo "SELECT * FROM gs_bm_table WHERE introduce LIKE '$image'";


if ( isset($kensaku) ) {
  $stmt = $pdo->prepare("SELECT * FROM gs_kadai_table WHERE introduce LIKE '%".$_POST["kensaku"]."%'");
  $status = $stmt->execute();
} else {
  $stmt = $pdo->prepare("SELECT * FROM gs_kadai_table WHERE sdgs LIKE '$image'");
  $status = $stmt->execute();  
};

// $stmt = $pdo->prepare("SELECT * FROM gs_bm_table WHERE introduce LIKE '%".$_POST["kensaku"]."%'");
// $status = $stmt->execute();

// $stmt = $pdo->prepare("SELECT * FROM gs_bm_table WHERE sdgs LIKE '$image'");
// $status = $stmt->execute();  

//データ表示
$view="";
if($status==false) {
  $error = $stmt->errorInfo();
  exit("ErrorQuery:".$error[2]);

}else{
  while( $result = $stmt->fetch(PDO::FETCH_ASSOC)){ 
    $view .= "<dev class='box'>";
    $view .= "<p>";
    $view .= $result['name'];
    $view .= "</p>";
    $view .= "<p>";
    $view .= $result['email'];
    $view .= "</p>";
    $view .= "<p>";
    $view .= $result['sdgs'];
    $view .= "</p>";
    $view .= "<p>";
    $view .= $result['introduce'];
    $view .= "</p>";
    $view .= "</dev>";
  }
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/result_stlyesheet.css">    
    <title>検索結果</title>
</head>
<body>
    <div>
        <div><?=$view?></div>
    </div>
</body>
</html>